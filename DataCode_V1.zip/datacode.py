import os
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
import numpy as np
import scipy.io.wavfile as wav
from scipy import signal

DATA_CODE_SOUNDS = {
    'A': ('beep', 1000, 0.1),
    'B': ('delay_beep', 1000, 2.0),
    'C': ('delay_beep', 1000, 1.0),
    'D': ('sequence', [400, 800], 0.15),
    'E': ('beep', 300, 0.1),
    'F': ('sequence', [600, 300, 600], 0.1),
    'G': ('trill', 1200, 0.3),
    'H': ('sequence_pause', [900, 900], 1.0),
    'I': ('beep', 1800, 0.04),
    'J': ('sequence_pause', [300, 1000], 2.0),
    'K': ('click_sequence', [1000], 0.1),
    'L': ('beep', 1000, 1.0),
    'M': ('sequence', [300, 300, 300], 0.15),
    'N': ('sequence', [1000, 1000, 1000], 0.15),
    'O': ('ring', 880, 0.4),
    'P': ('click_sequence', [1200, 1200], 0.1),
    'Q': ('static', None, 0.2),
    'R': ('sequence_pause', [1000, 300], 1.0),
    'S': ('hiss', None, 0.5),
    'T': ('sequence', [150, 1000], 0.15),
    'U': ('sequence', [1600, 1600], 0.05),
    'V': ('sequence_pause', [300, 300], 1.0),
    'W': ('sequence', [1600, 1600, 1600], 0.05),
    'X': ('static_double', None, 0.3),
    'Y': ('sequence', [300, 1500], 0.15),
    'Z': ('buzz', 120, 0.4),
    ' ': ('silence', None, 0.2),
    '\n': ('sequence', [200, 200], 0.3),
    '\t': ('silence', None, 0.5),
    '0': ('beep', 500, 0.1),
    '1': ('beep', 550, 0.1),
    '2': ('beep', 600, 0.1),
    '3': ('beep', 650, 0.1),
    '4': ('beep', 700, 0.1),
    '5': ('beep', 750, 0.1),
    '6': ('beep', 800, 0.1),
    '7': ('beep', 850, 0.1),
    '8': ('beep', 900, 0.1),
    '9': ('beep', 950, 0.1),
    '=': ('sequence', [700, 700], 0.1),
    '+': ('sequence', [800, 1200], 0.15),
    '-': ('sequence', [1200, 800], 0.15),
    '*': ('trill', 1500, 0.2),
    '/': ('static', None, 0.1),
    '(': ('beep', 1300, 0.08),
    ')': ('beep', 1100, 0.08),
    '"': ('click_sequence', [2000], 0.05),
    "'": ('click_sequence', [2000], 0.05),
    ':': ('sequence', [600, 900], 0.1),
    ',': ('beep', 400, 0.05),
    '!': ('static', None, 0.05),
    '<EOF>': ('siren', [1200, 400], 1.5)
}

def generate_wave(sound_type, param, duration, sample_rate=44100):
    t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
    
    if sound_type == 'beep':
        return np.sin(2 * np.pi * param * t)
    elif sound_type == 'silence':
        return np.zeros(int(sample_rate * duration))
    elif sound_type == 'sequence':
        waves = []
        seg_dur = duration / len(param)
        for freq in param:
            seg_t = np.linspace(0, seg_dur, int(sample_rate * seg_dur), endpoint=False)
            waves.append(np.sin(2 * np.pi * freq * seg_t))
        return np.concatenate(waves)
    elif sound_type == 'delay_beep':
        b1 = np.sin(2 * np.pi * param * np.linspace(0, 0.05, int(sample_rate * 0.05), endpoint=False))
        pause1 = np.zeros(int(sample_rate * duration))
        b2 = np.sin(2 * np.pi * param * np.linspace(0, 0.05, int(sample_rate * 0.05), endpoint=False))
        pause2 = np.zeros(int(sample_rate * 0.02))
        return np.concatenate([b1, pause1, b2, pause2, b2])
    elif sound_type == 'sequence_pause':
        f1, f2 = param
        w1 = np.sin(2 * np.pi * f1 * np.linspace(0, 0.08, int(sample_rate * 0.08), endpoint=False))
        pause = np.zeros(int(sample_rate * duration))
        w2 = np.sin(2 * np.pi * f2 * np.linspace(0, 0.08, int(sample_rate * 0.08), endpoint=False))
        return np.concatenate([w1, pause, w2])
    elif sound_type == 'trill':
        return np.sin(2 * np.pi * (param + 100 * np.sin(2 * np.pi * 50 * t)) * t)
    elif sound_type == 'click_sequence':
        click = np.random.normal(0, 0.4, int(sample_rate * 0.01))
        b_len = max(0.01, duration - 0.02) if len(param) > 1 else max(0.01, duration - 0.01)
        beep = np.sin(2 * np.pi * param[0] * np.linspace(0, b_len, int(sample_rate * b_len), endpoint=False))
        return np.concatenate([beep, click, beep]) if len(param) > 1 else np.concatenate([click, beep, click])
    elif sound_type == 'static':
        return np.random.normal(0, 0.2, len(t))
    elif sound_type == 'static_double':
        s1 = np.random.normal(0, 0.2, int(len(t)/3))
        return np.concatenate([s1, np.zeros(int(len(t)/3)), s1])
    elif sound_type == 'ring':
        return 0.5 * np.sin(2 * np.pi * param * t) + 0.5 * np.sin(2 * np.pi * (param + 5) * t)
    elif sound_type == 'hiss':
        return np.random.normal(0, 0.1, len(t))
    elif sound_type == 'buzz':
        return signal.sawtooth(2 * np.pi * param * t)
    elif sound_type == 'siren':
        f_start, f_end = param
        f_t = np.linspace(f_start, f_end, len(t))
        return np.sin(2 * np.pi * np.cumsum(f_t) / sample_rate)
    return np.zeros(int(sample_rate * duration))

class DataCodeGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("DCG - Data Code Generator")
        self.root.geometry("700x600")
        
        tk.Label(root, text="Enter Program Code or Text:", font=("Arial", 11, "bold")).pack(pady=5)
        
        self.text_area = scrolledtext.ScrolledText(root, width=80, height=8, font=("Courier", 10))
        self.text_area.pack(pady=5, padx=10)
        self.text_area.insert(tk.END, "")
        
        self.btn_generate = tk.Button(root, text="Compile to Data Code WAV", command=self.start_generation, bg="#4CAF50", fg="white", font=("Arial", 10, "bold"), padx=10, pady=5)
        self.btn_generate.pack(pady=10)
        
        tk.Label(root, text="DCG Processing Console Logs:", font=("Arial", 10, "bold")).pack(pady=2)
        self.log_area = scrolledtext.ScrolledText(root, width=80, height=18, font=("Courier", 9), bg="black", fg="lightgreen")
        self.log_area.pack(pady=5, padx=10, fill=tk.BOTH, expand=True)
        
        self.log("DCG Engine Initialized. Ready for code transmission encoding.")

    def log(self, message):
        self.log_area.insert(tk.END, f"[{time.strftime('%H:%M:%S')}] {message}\n")
        self.log_area.see(tk.END)

    def start_generation(self):
        text = self.text_area.get("1.0", tk.END).rstrip('\n')
        if not text:
            messagebox.showwarning("Warning", "Text area cannot be empty.")
            return
            
        file_path = filedialog.asksaveasfilename(
            defaultextension=".wav",
            filetypes=[("WAV Audio files", "*.wav")],
            title="Select Output Save Position"
        )
        
        if not file_path:
            self.log("Process cancelled: No output file path chosen.")
            return
            
        self.btn_generate.config(state=tk.DISABLED)
        threading.Thread(target=self.process_audio, args=(text, file_path), daemon=True).start()

    def process_audio(self, text, file_path):
        try:
            sample_rate = 44100
            audio_segments = []
            
            self.log(f"Starting Data Code Compilation for string sequence length: {len(text)}")
            
            for index, char in enumerate(text):
                lookup_char = char.upper()
                if lookup_char in DATA_CODE_SOUNDS:
                    sound_type, param, duration = DATA_CODE_SOUNDS[lookup_char]
                    visible_char = repr(char)
                    self.log(f"Processing char {visible_char} at position {index} -> Waveform type: {sound_type}, Duration: {duration}s")
                    
                    wave = generate_wave(sound_type, param, duration, sample_rate)
                    audio_segments.append(wave)
                    
                    boundary_silence = np.zeros(int(sample_rate * 0.01))
                    audio_segments.append(boundary_silence)
                    
                    time.sleep(0.01)
                else:
                    self.log(f"Skipping undefined Data Code character: {repr(char)}")
            
            self.log("Appending telemetry boundary marker: <EOF>")
            eof_type, eof_param, eof_dur = DATA_CODE_SOUNDS['<EOF>']
            audio_segments.append(generate_wave(eof_type, eof_param, eof_dur, sample_rate))
            
            self.log("Concatenating audio binary vectors...")
            full_audio = np.concatenate(audio_segments)
            
            if np.max(np.abs(full_audio)) > 0:
                self.log("Normalizing signal peaks to 16-bit float limits...")
                full_audio = full_audio / np.max(np.abs(full_audio))
                
            audio_int16 = (full_audio * 32767).astype(np.int16)
            
            self.log(f"Writing binary metadata to file structure: {os.path.basename(file_path)}")
            wav.write(file_path, sample_rate, audio_int16)
            
            self.log(f"Success. File compiled at: {file_path}")
            
            self.root.after(0, lambda: self.finish_success(file_path))
            
        except Exception as e:
            error_msg = str(e)
            self.log(f"CRITICAL COMPILATION FAULT: {error_msg}")
            self.root.after(0, lambda: self.finish_error(error_msg))

    def finish_success(self, path):
        self.btn_generate.config(state=tk.NORMAL)
        messagebox.showinfo("Compilation Complete", f"Data Code transmission compiled successfully!\n\nSaved to:\n{path}")

    def finish_error(self, error_msg):
        self.btn_generate.config(state=tk.NORMAL)
        messagebox.showerror("Compilation Error", f"The encoder encountered an error:\n{error_msg}")

if __name__ == "__main__":
    root = tk.Tk()
    app = DataCodeGUI(root)
    root.mainloop()


